import json
import re
import requests
import logging
from typing import List, Dict


class LLMClient:
    """Manages communication with the LLM provider."""

    def __init__(self, api_key: str, api_url: str, model: str) -> None:
        self.api_key = api_key
        self.api_url = api_url
        self.model = model

    def get_response(self, messages: List[Dict[str, str]]) -> str:
        """Get a response from the LLM.

        Args:
            messages: A list of message dictionaries.

        Returns:
            The LLM's response as a string.

        Raises:
            RequestException: If the request to the LLM fails.
        """
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}"
        }
        payload = {
            "messages": messages,
            "model": self.model,
            "temperature": 0.85,
            # "max_tokens": 4096,
            "top_p": 1,
            "stream": False,
            "stop": None
        }

        try:
            response = requests.post(self.api_url, headers=headers, json=payload)
            response.raise_for_status()
            data = response.json()
            content = data['choices'][0]['message']['content']
            return self.extract_text_and_json(content)
        except requests.exceptions.RequestException as e:
            logging.error(f"Error getting LLM response: {str(e)}")
            if e.response is not None:
                logging.error(f"Status code: {e.response.status_code}")
                logging.error(f"Response details: {e.response.text}")
            return f"Error: {str(e)}"

    @staticmethod
    def extract_text_and_json(input_text):
        match = re.search(r'({.*)', input_text, re.DOTALL)
        if not match:
            logging.info("\n not match Assistant: %s", input_text)
            return input_text

        explanation = input_text[:match.start()].strip()
        if explanation:
            logging.info("\n explanation Assistant: %s", explanation)

        json_part = match.group(1).strip()

        return json_part