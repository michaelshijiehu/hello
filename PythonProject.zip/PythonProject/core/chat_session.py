import asyncio
import json
import logging
from typing import List, Dict
from .server import Server
from .llm_client import LLMClient


class ChatSession:
    """Orchestrates the interaction between user, LLM, and tools."""

    def __init__(self, servers: List[Server], llm_client: LLMClient) -> None:
        self.servers = servers
        self.llm_client = llm_client

    @staticmethod
    def is_valid_json(json_str: str) -> bool:
        """Check if the provided string is a valid JSON.

        Args:
            json_str: The string to check.

        Returns:
            True if the string is a valid JSON, False otherwise.
        """
        try:
            json.loads(json_str)
            return True
        except json.JSONDecodeError:
            return False

    async def cleanup_servers(self) -> None:
        """Clean up all servers properly."""
        await asyncio.gather(*(s.cleanup() for s in self.servers), return_exceptions=True)

    async def process_llm_response(self, llm_response: str) -> str:
        """Process the LLM response and execute tools if needed.

        Args:
            llm_response: The response from the LLM.

        Returns:
            The result of tool execution or the original response.
        """
        try:
            logging.info("\nprocess_tool: %s", llm_response)
            tool_call = json.loads(llm_response)
            if "tool" in tool_call and "arguments" in tool_call:
                logging.info(f"Executing tool: {tool_call['tool']}")
                logging.info(f"With arguments: {tool_call['arguments']}")

                for server in self.servers:
                    tools = await server.list_tools()
                    if any(tool.name == tool_call["tool"] for tool in tools):
                        try:
                            result = await server.execute_tool(
                                tool_call["tool"],
                                tool_call["arguments"])

                            if isinstance(result, dict) and 'progress' in result:
                                progress = result['progress']
                                total = result['total']
                                logging.info(f"Progress: {progress}/{total} ({(progress/total)*100:.1f}%)")

                            logging.error(f"McpSever result: {result}")
                            return f"Tool execution result: {result}"
                        except Exception as e:
                            error_msg = f"Error executing tool: {str(e)}"
                            logging.error(error_msg)
                            return error_msg

                return f"No server found with tool: {tool_call['tool']}"
            return llm_response
        except json.JSONDecodeError:
            logging.error(f"McpSever Error: {llm_response}")
            return llm_response


    async def process(self, user_input: str) -> str:
        """
        处理单轮用户输入，调用 LLM，执行工具（如果需要），返回最终回复文本。
        """

        # 获取所有工具描述，供 LLM 参考
        tools_description = "\n".join([
            tool.format_for_llm()
            for server in self.servers
            for tool in await server.list_tools()
        ])

        system_message = f"""You are a helpful assistant with access to these tools:

{tools_description}

You are an intelligent assistant that follows instructions carefully.

Your task is to assist the user with their request. The rules for using tools are as follows:

1.!strict: If you need a tool call, you must respond ONLY with the exact JSON object in the format shown below.And always execute one tool per time. Do not add any extra text or explanation:

{{
    "tool": "tool-name",
    "arguments": {{
        "argument-name": "value"
    }},
    "content": "what you wanna said"
}}
!

2. After receiving the tool's response, you need to:
   a. Convert the raw response into a natural and conversational reply.
   b. Keep the response concise and to the point.
   c. Focus on the most relevant information.
   d. Use the context from the user's question.
   e. Do not simply repeat the raw data.

3. Only use the tools that have been explicitly defined and provided.

4. If no tool is needed, provide a direct and helpful response to the user.

5. If the previous step exist error, provide necessary info for user fix that issue.
Remember to follow these rules precisely to ensure the best user experience.
"""

        messages = [
            {"role": "system", "content": system_message},
            {"role": "user", "content": user_input}
        ]

        # 调用 LLM 客户端获取回复（如果 llm_client.get_response 是同步，建议改成异步版本）
        llm_response = self.llm_client.get_response(messages)

        # 判断 LLM 回复是否为工具调用的 JSON 格式
        if self.is_valid_json(llm_response):
            # 解析并执行工具调用
            result = await self.process_llm_response(llm_response)
            return result
        else:
            # 直接返回 LLM 生成的文本回复
            return llm_response

    async def build_system_prompt(self) -> str:
        tools_description = "\n".join([
            tool.format_for_llm()
            for server in self.servers
            for tool in await server.list_tools()
        ])
        return (
            "You are a helpful assistant. You can use the following tools:\n\n"
            f"{tools_description}\n\n"
            "When the user asks a question, call the most relevant tool. "
            "Do not guess or answer on your own if the tool is available."
        )