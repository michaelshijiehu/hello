import asyncio
import logging
import os
import shutil
from typing import Any, Dict, List, Optional

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from mcp.client.sse import sse_client
from .tool import Tool


class Server:
    """Manages MCP server connections and tool execution."""

    def __init__(self, name: str, config: Dict[str, Any]) -> None:
        self.name = name
        self.config = config
        self.stdio_context = None
        self.session = None
        self._cleanup_lock = asyncio.Lock()
        self.capabilities = None
        self.timeout = self.config.get('timeout', 60)

    async def initialize(self) -> None:
        """Initialize the server connection."""
        try:
            transport_type = self.config.get('transportType', 'stdio')
            if transport_type == 'stdio':
                server_params = StdioServerParameters(
                    command=shutil.which("npx") if self.config['command'] == "npx" else self.config['command'],
                    args=self.config['args'],
                    env={**os.environ, **self.config.get('env', {})}
                )
                self.stdio_context = stdio_client(server_params)
            elif transport_type == 'sse':
                url = self.config.get('url')
                if not url:
                    raise ValueError(f"SSE server {self.name} requires a 'url' field")
                self.stdio_context = sse_client(url)
            else:
                raise ValueError(f"Unknown transport type '{transport_type}' for server '{self.name}'")

            read, write = await asyncio.wait_for(self.stdio_context.__aenter__(), timeout=self.timeout)
            self.session = ClientSession(read, write)
            await self.session.__aenter__()
            self.capabilities = await self.session.initialize()
        except Exception as e:
            logging.error(f"Error initializing server {self.name}: {e}")
            await self.cleanup()
            raise

    async def list_tools(self) -> List[Tool]:
        """List available tools from the server.

               Returns:
                   A list of available tools.

               Raises:
                   RuntimeError: If the server is not initialized.
               """
        if not self.session:
            raise RuntimeError(f"Server {self.name} not initialized")

        tools_response = await self.session.list_tools()
        tools = []

        supports_progress = (
            self.capabilities
            and 'progress' in self.capabilities
        )

        if supports_progress:
            logging.info(f"Server {self.name} supports progress tracking")

        for item in tools_response:
            if isinstance(item, tuple) and item[0] == 'tools':
                for tool in item[1]:
                    tools.append(Tool(tool.name, tool.description, tool.inputSchema))
                    if supports_progress:
                        logging.info(f"Tool '{tool.name}' will support progress tracking")
        return tools

    async def execute_tool(
            self,
            tool_name: str,
            arguments: Dict[str, Any],
            retries: int = 2,
            delay: float = 1.0
    ) -> Any:
        """Execute a tool with retry mechanism.

                Args:
                    tool_name: Name of the tool to execute.
                    arguments: Tool arguments.
                    retries: Number of retry attempts.
                    delay: Delay between retries in seconds.

                Returns:
                    Tool execution result.

                Raises:
                    RuntimeError: If server is not initialized.
                    Exception: If tool execution fails after all retries.
                """
        if not self.session:
            raise RuntimeError(f"Server {self.name} not initialized")

        for attempt in range(retries):
            try:
                supports_progress = (
                        self.capabilities
                        and 'progress' in self.capabilities
                )

                if supports_progress:
                    logging.info(f"Executing {tool_name} with progress tracking...")
                    result = await self.session.call_tool(
                        tool_name,
                        arguments,
                        progress_token=f"{tool_name}_execution"
                    )
                else:
                    logging.info(f"Executing {tool_name}...")
                    result = await self.session.call_tool(tool_name, arguments)

                return result

            except Exception as e:
                logging.warning(f"Attempt {attempt+1} failed: {e}")
                if attempt < retries - 1:
                    await asyncio.sleep(delay)
                else:
                    raise

    async def cleanup(self) -> None:
        """Clean up server resources."""
        async with self._cleanup_lock:
            if self.session:
                try:
                    await self.session.__aexit__(None, None, None)
                except Exception:
                    pass
                self.session = None
            if self.stdio_context:
                try:
                    await self.stdio_context.__aexit__(None, None, None)
                except Exception:
                    pass
                self.stdio_context = None