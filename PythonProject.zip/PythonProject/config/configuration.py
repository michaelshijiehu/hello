import json
import os
from typing import Dict, Any
from dotenv import load_dotenv


class Configuration:
    def __init__(self) -> None:
        self.load_env()
        self.api_key = os.getenv("GROQ_API_KEY") or os.getenv("GITHUB_API_KEY") or os.getenv("LLM_API_KEY")
        self.api_url = os.getenv("LLM_API_URL", "https://api.siliconflow.cn/v1/chat/completions")
        self.model = os.getenv("LLM_MODEL", "Qwen/Qwen2.5-72B-Instruct-128K")

    @staticmethod
    def load_env() -> None:
        """Load environment variables from .env file."""
        load_dotenv()

    @staticmethod
    def load_config(file_path: str) -> Dict[str, Any]:
        """Load server configuration from JSON file.

         Args:
             file_path: Path to the JSON configuration file.

         Returns:
             Dict containing server configuration.

         Raises:
             FileNotFoundError: If configuration file doesn't exist.
             JSONDecodeError: If configuration file is invalid JSON.
         """
        with open(file_path, 'r') as f:
            return json.load(f)

    @property
    def llm_api_key(self) -> str:
        """Get the LLM API key.

          Returns:
              The API key as a string.

          Raises:
              ValueError: If the API key is not found in environment variables.
          """
        if not self.api_key:
            raise ValueError("LLM_API_KEY not found in environment variables")
        return self.api_key

    @property
    def llm_api_url(self) -> str:
        return self.api_url

    @property
    def llm_model(self) -> str:
        return self.model