from flask import Flask, request, jsonify

app = Flask(__name__)

def say_hello(name="World"):
    return f"Hello, {name}!"

@app.route('/hello', methods=['GET'])
def hello_endpoint():
    # 获取查询参数 ?name=xxx
    name = request.args.get('name', 'World')
    message = say_hello(name)
    return jsonify({"message": message})

if __name__ == '__main__':
    app.run(debug=True, host="0.0.0.0", port=5000)
