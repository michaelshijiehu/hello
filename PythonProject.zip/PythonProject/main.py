from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from pydantic import BaseModel
import asyncio

from config.configuration import Configuration
from core.chat_session import ChatSession
from core.llm_client import LLMClient
from core.server import Server

import uvicorn
import logging
import os
import json

logging.basicConfig(level=logging.INFO)

# ----------- 初始化 -----------
config = Configuration()
llm_client = LLMClient(config.llm_api_key, config.llm_api_url, config.llm_model)

# 从配置文件加载 MCP Server
config_path = os.getenv("MCP_CONFIG_PATH", "servers_config.json")
server_configs = Configuration.load_config(config_path)
servers = [Server(name, cfg) for name, cfg in server_configs.get("mcpServers", {}).items()
]

# 启动时初始化 MCP server
@asynccontextmanager
async def lifespan(app: FastAPI):
    # startup
    for server in servers:
        await server.initialize()
    logging.info("✅ MCP Servers initialized")

    yield  # 应用运行中...

    # shutdown
    await asyncio.gather(*(server.cleanup() for server in servers))

app = FastAPI(lifespan=lifespan)


# ----------- 接口定义 -----------
class ChatRequest(BaseModel):
    prompt: str

class ChatResponse(BaseModel):
    message: str

@app.post("/chat", response_model=ChatResponse)
async def chat_endpoint(request: ChatRequest):
    session = ChatSession(servers, llm_client)

    system_prompt = await session.build_system_prompt()
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": request.prompt}
    ]

    max_retry = 20  # 避免死循环
    for _ in range(max_retry):
        llm_response = llm_client.get_response(messages)
        if session.is_valid_json(llm_response):
            # 处理 JSON 结果，更新 messages，继续调用 get_response
            messages = await session.process_llm_response(llm_response)
        else:
            # 返回最终结论
            return ChatResponse(message=llm_response)

    # 超出最大重试次数，返回错误或最后一次结果
    return ChatResponse(message="LLM 未返回有效结论，超出最大尝试次数")


if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
